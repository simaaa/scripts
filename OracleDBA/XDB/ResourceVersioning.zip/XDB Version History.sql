SELECT --p.resid,
  tbl.owner, p.path, tbl.VersionID, tbl.VCRUID, tbl.Parents as resid_parent,
  tbl.Creator, TO_DATE(tbl.CreationDate, 'YYYY.MM.DD"T"HH24:MI:SS') CreationDate,
  --tbl.LastModifier, TO_DATE(tbl.ModificationDate, 'YYYY.MM.DD"T"HH24:MI:SS') ModificationDate,
  (xdburitype(p.path).getxml()).getStringVal() AS TEXT,
    
  tbl_prev.VersionID AS PREV_VersionID, --tbl_prev.VCRUID AS PREV_VCRUID, tbl_prev.Parents AS PREV_resid_parent,
  --tbl_prev.Creator AS PREV_Creator, TO_DATE(tbl_prev.CreationDate, 'YYYY.MM.DD"T"HH24:MI:SS') PREV_CreationDate,
  tbl_prev.LastModifier AS PREV_LastModifier, TO_DATE(tbl_prev.ModificationDate, 'YYYY.MM.DD"T"HH24:MI:SS') PREV_ModificationDate,
  CASE WHEN tbl.Parents IS NULL THEN NULL ELSE (DBMS_XDB_VERSION.GetContentsXmlByResId(tbl.Parents)).getStringVal() END AS PREV_TEXT
FROM
  path_view p,
  XMLTABLE(XMLNAMESPACES(DEFAULT 'http://xmlns.oracle.com/xdb/XDBResource.xsd'), 'for $i in /Resource return $i' PASSING p.res COLUMNS
    VersionID        number        PATH '@VersionID',
    Owner            varchar2(100) PATH 'Owner',
    Creator          varchar2(100) PATH 'Creator',
    CreationDate     varchar2(19)  PATH 'CreationDate',
    LastModifier     varchar2(100) PATH 'LastModifier',
    ModificationDate varchar2(19)  PATH 'ModificationDate',
    VCRUID           varchar2(100) PATH 'VCRUID',
    Parents          varchar2(100) PATH 'Parents'
  ) tbl,
  XMLTABLE(XMLNAMESPACES(DEFAULT 'http://xmlns.oracle.com/xdb/XDBResource.xsd'), 'for $i in /Resource return $i' PASSING DBMS_XDB_VERSION.GetResourceByResId(tbl.Parents) COLUMNS
    VersionID        number        PATH '@VersionID',
    Owner            varchar2(100) PATH 'Owner',
    Creator          varchar2(100) PATH 'Creator',
    CreationDate     varchar2(19)  PATH 'CreationDate',
    LastModifier     varchar2(100) PATH 'LastModifier',
    ModificationDate varchar2(19)  PATH 'ModificationDate',
    VCRUID           varchar2(100) PATH 'VCRUID',
    Parents          varchar2(100) PATH 'Parents'
  ) tbl_prev
WHERE tbl.VersionID IS NOT NULL -- FILTER only versioned content
AND p.path like '/public/mboo/teszt.xml'
