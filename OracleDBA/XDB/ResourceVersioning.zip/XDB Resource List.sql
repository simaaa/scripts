SELECT t.* FROM (
  SELECT
    owner, 
    path, container, displayname,
    characterset, contenttype, invalid, versionhistory,
    creator, to_date(creationdate, 'yyyy-mm-dd"T"hh24:mi:ss') creationdate,
    lastmodifier, to_date(modificationdate, 'yyyy-mm-dd"T"hh24:mi:ss') modificationdate,
    CASE WHEN VCRUID IS NOT NULL THEN 'true' ELSE 'false' END AS isVersioned,
    VCRUID, Parents
    ,res
  FROM path_view, XMLTABLE(XMLNAMESPACES(DEFAULT 'http://xmlns.oracle.com/xdb/XDBResource.xsd'), 'for $i in /Resource return $i' PASSING res COLUMNS
    container        VARCHAR2(5)   PATH '@Container',
    displayname      VARCHAR2(128) PATH 'DisplayName',
    owner            VARCHAR2(64)  PATH 'Owner',
    creator          VARCHAR2(64)  PATH 'Creator',
    lastmodifier     VARCHAR2(64)  PATH 'LastModifier',
    creationdate     VARCHAR2(19)  PATH 'CreationDate',
    modificationdate VARCHAR2(19)  PATH 'ModificationDate',
    characterset     VARCHAR2(128) PATH 'CharacterSet',
    contenttype      VARCHAR2(128) PATH 'ContentType',
    invalid          VARCHAR2(5)   PATH '@Invalid',
    versionhistory   VARCHAR2(5)   PATH '@VersionHistory',
    VCRUID           VARCHAR2(100) PATH 'VCRUID',
    Parents          VARCHAR2(100) PATH 'Parents'
  )
  --WHERE VCRUID IS NOT NULL
) t WHERE 1=1
--AND t.container != 'false'
--AND t.isVersioned = 'true'
AND t.path like '%/mboo/%'
ORDER BY t.path;
