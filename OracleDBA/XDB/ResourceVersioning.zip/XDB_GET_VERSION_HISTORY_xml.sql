SELECT
  res.res,
  ver.*
FROM
  resource_view res,
  TABLE(XDB_GET_VERSION_HISTORY('/public/mboo/teszt.xml')) vh,
  XMLTABLE(
    XMLNAMESPACES(DEFAULT 'http://xmlns.oracle.com/xdb/XDBResource.xsd'), '/Resource' PASSING VALUE (vh)
    COLUMNS
      VERSION_NO      NUMBER(1)    PATH '@VersionID',
      DATE_CREATED    TIMESTAMP(7) PATH 'CreationDate',
      DATE_MODIFIED   TIMESTAMP(7) PATH 'ModificationDate',
      CONTENT_CLOB    CLOB         PATH 'Contents',
      CONTENT_XML     XMLTYPE      PATH 'Contents'
  ) ver
WHERE res.any_path = '/public/mboo/teszt.xml'
ORDER BY ver.VERSION_NO;
