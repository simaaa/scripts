SELECT
  res.res,
  ver.*
FROM
  resource_view res,
  TABLE(XDB_GET_VERSION_HISTORY('/public/mboo/text.txt')) vh,
  XMLTABLE(
    XMLNAMESPACES(DEFAULT 'http://xmlns.oracle.com/xdb/XDBResource.xsd'), '/Resource' PASSING VALUE (vh)
    COLUMNS
      VERSION_NO      NUMBER(1)    PATH '@VersionID',
      DATE_CREATED    TIMESTAMP(7) PATH 'CreationDate',
      DATE_MODIFIED   TIMESTAMP(7) PATH 'ModificationDate',
      CONTENT         CLOB         PATH 'Contents/text/text()'
  ) ver
WHERE res.any_path = '/public/mboo/text.txt'
ORDER BY ver.VERSION_NO;
