DECLARE
  --v_file        VARCHAR2(1000) := '/public/mboo/teszt.xml';
  v_file        VARCHAR2(1000) := '/public/mboo/teszt2.xml';
BEGIN
  IF DBMS_XDB_VERSION.isCheckedOut(v_file) THEN
    DBMS_OUTPUT.PUT_LINE('The file is checked out! (' || v_file || ')');
  ELSE
    DBMS_OUTPUT.PUT_LINE('The file is NOT checked out! (' || v_file || ')');
  END IF;
END;
/
