DECLARE
  --v_file        VARCHAR2(1000) := '/public/mboo/teszt.xml';
  v_file        VARCHAR2(1000) := '/public/mboo/teszt2.xml';
  v_resid       DBMS_XDB_VERSION.RESID_TYPE;
BEGIN
  v_resid := DBMS_XDB_VERSION.MakeVersioned(v_file);
  DBMS_OUTPUT.PUT_LINE('----> MakeVersioned RESID: ' || v_resid);
  COMMIT;
END;
/
