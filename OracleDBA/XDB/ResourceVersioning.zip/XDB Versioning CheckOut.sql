DECLARE
  --v_file        VARCHAR2(1000) := '/public/mboo/teszt.xml';
  v_file        VARCHAR2(1000) := '/public/mboo/teszt2.xml';
BEGIN
  IF DBMS_XDB_VERSION.isCheckedOut(v_file) THEN
    RAISE_APPLICATION_ERROR(-20000, 'The file is already checked out! (' || v_file || ')');
  END IF;
  DBMS_XDB_VERSION.CheckOut(v_file);
  COMMIT;
END;
/
